import os

BOT_TOKEN = os.environ.get("BOT_TOKEN", "")
DB_PATH = os.environ.get("DB_PATH", "shelflife.db")
DEFAULT_TZ = "Europe/Moscow"
MAX_ITEMS_PER_USER = 200
