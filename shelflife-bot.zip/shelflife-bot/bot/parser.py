import re
from datetime import date

CUR = {"rub": "RUB", "руб": "RUB", "р": "RUB", "₽": "RUB",
       "usd": "USD", "$": "USD", "eur": "EUR", "€": "EUR"}

PATTERN = re.compile(
    r"^(?P<name>.+?)\s+(?P<d>\d{1,2})\.(?P<m>\d{1,2})(?:\.(?P<y>\d{4}|\d{2}))?"
    r"(?:\s+(?P<cur0>[$€₽])?(?P<cost>\d+(?:[.,]\d+)?)\s*(?P<cur>rub|руб|р|₽|usd|\$|eur|€)?)?$",
    re.IGNORECASE,
)


def parse_add(text: str, today: date):
    """'Spotify 15.11 500rub' -> {title, due, cost, currency} или None."""
    m = PATTERN.match((text or "").strip())
    if not m:
        return None
    y = int(m["y"]) if m["y"] else today.year
    if y < 100:
        y += 2000
    try:
        due = date(y, int(m["m"]), int(m["d"]))
    except ValueError:
        return None
    if not m["y"] and due < today:
        try:
            due = date(y + 1, due.month, due.day)
        except ValueError:
            return None
    cost = float(m["cost"].replace(",", ".")) if m["cost"] else None
    cur_raw = (m["cur"] or m["cur0"] or "rub").lower()
    return {"title": m["name"].strip(), "due": due, "cost": cost,
            "currency": CUR.get(cur_raw, "RUB")}
