import sqlite3

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  telegram_id INTEGER UNIQUE,
  name TEXT,
  tz TEXT NOT NULL DEFAULT 'Europe/Moscow',
  notify_time TEXT NOT NULL DEFAULT '09:00',
  remind_days TEXT NOT NULL DEFAULT '7,3,1,0',
  notify_tg INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS items(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'Подписка',
  next_date TEXT NOT NULL,
  repeat_n INTEGER NOT NULL DEFAULT 1,
  repeat_unit TEXT,              -- day|week|month|year; NULL = разовая вещь
  cost REAL,
  currency TEXT NOT NULL DEFAULT 'RUB',
  is_paid INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'active',   -- active|cancelled|archived
  snoozed_until TEXT
);
CREATE INDEX IF NOT EXISTS items_user ON items(user_id, status);
CREATE TABLE IF NOT EXISTS notifications_log(
  item_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  due_date TEXT NOT NULL,
  kind TEXT NOT NULL,
  sent_at TEXT DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(item_id, user_id, due_date, kind)
);
CREATE TABLE IF NOT EXISTS link_tokens(
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL,
  expires_at TEXT NOT NULL,
  used_at TEXT
);
"""


class DB:
    """Тонкая обёртка над sqlite3. Для MVP; на PostgreSQL меняется только этот файл."""

    def __init__(self, path: str):
        self.c = sqlite3.connect(path, check_same_thread=False)
        self.c.row_factory = sqlite3.Row
        self.c.executescript(SCHEMA)
        self.c.commit()

    def q(self, sql, args=()):
        return self.c.execute(sql, args).fetchall()

    def one(self, sql, args=()):
        return self.c.execute(sql, args).fetchone()

    def run(self, sql, args=()):
        cur = self.c.execute(sql, args)
        self.c.commit()
        return cur
