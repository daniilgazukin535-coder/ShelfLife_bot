import asyncio
import html
import logging
import re
import uuid
from datetime import date, datetime, timezone
from zoneinfo import ZoneInfo

from aiogram import Bot, Dispatcher, F, Router
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError, TelegramRetryAfter
from aiogram.filters import Command, CommandObject, CommandStart
from aiogram.types import (BotCommand, CallbackQuery, InlineKeyboardButton,
                           InlineKeyboardMarkup, Message)
from apscheduler.schedulers.asyncio import AsyncIOScheduler

from . import config, services
from .db import DB
from .parser import parse_add

db = DB(config.DB_PATH)
router = Router()
drafts: dict[str, dict] = {}     # черновики /add; при перезапуске бота теряются (для MVP ок)

HELP = (
    "<b>ShelfLife</b> напоминает о платежах и сроках годности.\n\n"
    "<b>Добавить:</b> <code>/add Spotify 15.11 500rub</code>\n"
    "Формат: название, дата ДД.ММ (или ДД.ММ.ГГГГ), необязательно сумма и валюта "
    "(rub, usd, eur, ₽, $, €).\n\n"
    "/list — всё, что отслеживается\n"
    "/spend — траты в месяц по подпискам\n"
    "/time 09:00 — во сколько присылать напоминания\n"
    "/days 7,3,1,0 — за сколько дней напоминать\n"
    "/tz Europe/Moscow — часовой пояс"
)


def kb(rows):
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=t, callback_data=c)] for t, c in rows])


def me(tg_user):
    return services.get_or_create_user(db, tg_user.id, tg_user.full_name)


async def edit(cb: CallbackQuery, text: str):
    try:
        await cb.message.edit_text(text, reply_markup=None)
    except (TelegramBadRequest, AttributeError):
        pass


# ---------- команды ----------
@router.message(CommandStart())
async def start(m: Message, command: CommandObject):
    me(m.from_user)
    if command.args:
        _, text = services.link_account(db, m.from_user.id, command.args.strip())
        await m.answer(text)
        return
    await m.answer("Привет! 👋\n\n" + HELP)


@router.message(Command("help"))
async def help_(m: Message):
    await m.answer(HELP)


@router.message(Command("add"))
async def add(m: Message, command: CommandObject):
    u = me(m.from_user)
    parsed = parse_add(command.args or "", services.local_today(u))
    if not parsed or len(parsed["title"]) > 100:
        await m.answer("Не понял формат. Пример: <code>/add Spotify 15.11 500rub</code>")
        return
    if len(services.active_items(db, u["id"])) >= config.MAX_ITEMS_PER_USER:
        await m.answer("Достигнут лимит карточек. Удалите ненужные через /list.")
        return
    if len(drafts) > 1000:
        drafts.clear()
    did = uuid.uuid4().hex[:8]
    drafts[did] = {"tg": m.from_user.id, **parsed}
    cost = f" · {services.money(parsed['cost'], parsed['currency'])}" if parsed["cost"] else ""
    await m.answer(
        f"Добавить <b>{html.escape(parsed['title'])}</b> на {parsed['due']:%d.%m.%Y}{cost}?\nКак часто повторять?",
        reply_markup=kb([("Разово", f"add:{did}:once"), ("Каждый месяц", f"add:{did}:month"),
                         ("Каждый год", f"add:{did}:year"), ("Отмена", f"add:{did}:x")]))


@router.message(Command("list"))
async def list_(m: Message):
    u = me(m.from_user)
    items = services.active_items(db, u["id"])
    if not items:
        await m.answer("Пока пусто. Добавьте первую карточку: <code>/add Spotify 15.11 500rub</code>")
        return
    today = services.local_today(u)
    lines = []
    for it in items[:40]:
        left = (date.fromisoformat(it["next_date"]) - today).days
        cost = f" · {services.money(it['cost'], it['currency'])}" if it["cost"] else ""
        lines.append(f"{services.status_emoji(left)} <b>{html.escape(it['title'])}</b> — {services.when(left)}{cost}")
    await m.answer("\n".join(lines))


@router.message(Command("spend"))
async def spend(m: Message):
    u = me(m.from_user)
    totals = services.monthly_totals(services.active_items(db, u["id"]))
    if not totals:
        await m.answer("Платных подписок пока нет.")
        return
    order = sorted(totals, key=lambda c: c != "RUB")
    await m.answer("Подписки в месяц:\n" + "\n".join(f"• {services.money(totals[c], c)}" for c in order)
                   + "\n\nВалюты не смешиваются.")


@router.message(Command("time"))
async def set_time(m: Message, command: CommandObject):
    u = me(m.from_user)
    mt = re.fullmatch(r"([01]?\d|2[0-3]):([0-5]\d)", (command.args or "").strip())
    if not mt:
        await m.answer("Укажите время так: <code>/time 09:00</code>")
        return
    val = f"{int(mt[1]):02d}:{mt[2]}"
    db.run("UPDATE users SET notify_time=? WHERE id=?", (val, u["id"]))
    await m.answer(f"Буду присылать напоминания в {val}.")


@router.message(Command("days"))
async def set_days(m: Message, command: CommandObject):
    u = me(m.from_user)
    try:
        vals = sorted({int(x) for x in (command.args or "").replace(" ", "").split(",")}, reverse=True)
        assert vals and len(vals) <= 6 and all(0 <= v <= 90 for v in vals)
    except Exception:
        await m.answer("Пример: <code>/days 7,3,1,0</code> (до 6 значений, от 0 до 90)")
        return
    db.run("UPDATE users SET remind_days=? WHERE id=?", (",".join(map(str, vals)), u["id"]))
    await m.answer("Напоминать за: " + ", ".join(map(str, vals)) + " дн.")


@router.message(Command("tz"))
async def set_tz(m: Message, command: CommandObject):
    u = me(m.from_user)
    try:
        ZoneInfo((command.args or "").strip())
    except Exception:
        await m.answer("Не знаю такой часовой пояс. Пример: <code>/tz Europe/Moscow</code>")
        return
    db.run("UPDATE users SET tz=? WHERE id=?", (command.args.strip(), u["id"]))
    await m.answer(f"Часовой пояс: {command.args.strip()}")


# ---------- кнопки ----------
@router.callback_query(F.data.startswith("add:"))
async def cb_add(cb: CallbackQuery):
    _, did, mode = cb.data.split(":")
    d = drafts.pop(did, None)
    if mode == "x":
        await edit(cb, "Отменено.")
        await cb.answer()
        return
    if not d or d["tg"] != cb.from_user.id:
        await cb.answer("Черновик устарел, повторите /add", show_alert=True)
        return
    u = me(cb.from_user)
    services.add_item(db, u["id"], d["title"], d["due"], d["cost"], d["currency"], mode)
    await edit(cb, f"✅ Добавлено: {html.escape(d['title'])}, {d['due']:%d.%m.%Y}")
    await cb.answer("Готово")


@router.callback_query(F.data.regexp(r"^[rcsd]:\d+:\d{4}-\d{2}-\d{2}$"))
async def cb_action(cb: CallbackQuery):
    action, item_id, due = cb.data.split(":")
    u = me(cb.from_user)
    code, it = services.apply_action(db, u, action, int(item_id), due)
    if code in ("notfound", "stale", "once"):
        await cb.answer("Это напоминание уже неактуально. Загляните в /list", show_alert=True)
        return
    t = html.escape(it["title"])
    text = {
        "r": f"✅ {t}: продлено, следующая дата {date.fromisoformat(it['next_date']):%d.%m.%Y}",
        "c": f"❌ {t}: отменено, больше не напомню",
        "s": f"⏰ {t}: напомню завтра",
        "d": f"🗑 {t}: убрано в архив",
    }[action]
    await edit(cb, text)
    await cb.answer()


# ---------- рассылка напоминаний ----------
async def send_reminders(bot: Bot):
    for u, it, kind, left in services.collect_reminders(db, datetime.now(timezone.utc)):
        if not services.claim(db, it["id"], u["id"], it["next_date"], kind):
            continue
        try:
            await bot.send_message(u["telegram_id"], services.reminder_text(it, left),
                                   reply_markup=kb(services.keyboard_spec(it)))
            services.after_sent(db, it, kind)
            await asyncio.sleep(0.05)       # бережём лимиты Telegram
        except TelegramForbiddenError:      # пользователь заблокировал бота
            db.run("UPDATE users SET notify_tg=0 WHERE id=?", (u["id"],))
        except TelegramRetryAfter as e:
            services.unclaim(db, it["id"], u["id"], it["next_date"], kind)
            await asyncio.sleep(e.retry_after)
        except Exception:
            logging.exception("не удалось отправить напоминание")
            services.unclaim(db, it["id"], u["id"], it["next_date"], kind)


async def main():
    logging.basicConfig(level=logging.INFO)
    if not config.BOT_TOKEN:
        raise SystemExit("Задайте BOT_TOKEN (токен от @BotFather)")
    bot = Bot(config.BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher()
    dp.include_router(router)
    await bot.set_my_commands([
        BotCommand(command="add", description="Добавить: /add Spotify 15.11 500rub"),
        BotCommand(command="list", description="Что отслеживается"),
        BotCommand(command="spend", description="Траты в месяц"),
        BotCommand(command="time", description="Время напоминаний"),
        BotCommand(command="days", description="За сколько дней напоминать"),
        BotCommand(command="help", description="Помощь"),
    ])
    sched = AsyncIOScheduler()
    sched.add_job(send_reminders, "interval", minutes=15, args=[bot],
                  next_run_time=datetime.now(), max_instances=1, coalesce=True)
    sched.start()
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
