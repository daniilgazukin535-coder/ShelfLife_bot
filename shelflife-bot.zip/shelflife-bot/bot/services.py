"""Бизнес-логика без зависимостей от Telegram: её можно вызывать и с сайта."""
import calendar
import hashlib
import html
import secrets
from datetime import date, datetime, timedelta, timezone
from zoneinfo import ZoneInfo

from .config import DEFAULT_TZ

UNIT_NAME = {"day": "день", "week": "неделю", "month": "месяц", "year": "год"}
UNIT_SHORT = {"day": "дн.", "week": "нед.", "month": "мес.", "year": "г."}


# ---------- даты и форматирование ----------
def add_interval(d: date, n: int, unit: str) -> date:
    if unit == "day":
        return d + timedelta(days=n)
    if unit == "week":
        return d + timedelta(weeks=n)
    months = n if unit == "month" else 12 * n
    y, m0 = divmod(d.year * 12 + d.month - 1 + months, 12)
    m = m0 + 1
    return date(y, m, min(d.day, calendar.monthrange(y, m)[1]))


def tz_of(u) -> ZoneInfo:
    try:
        return ZoneInfo(u["tz"])
    except Exception:
        return ZoneInfo(DEFAULT_TZ)


def local_today(u, now: datetime | None = None) -> date:
    now = now or datetime.now(timezone.utc)
    return now.astimezone(tz_of(u)).date()


def plural_days(n: int) -> str:
    a, b = n % 10, n % 100
    if 10 < b < 15:
        return f"{n} дней"
    return f"{n} день" if a == 1 else f"{n} дня" if 1 < a < 5 else f"{n} дней"


def when(left: int) -> str:
    if left < 0:
        return f"просрочено на {plural_days(-left)}"
    if left == 0:
        return "сегодня"
    if left == 1:
        return "завтра"
    return f"через {plural_days(left)}"


def money(v, cur: str) -> str:
    s = f"{v:.2f}".rstrip("0").rstrip(".")
    return {"RUB": f"{s} ₽", "USD": f"${s}", "EUR": f"{s} €"}.get(cur, f"{s} {cur}")


def status_emoji(left: int) -> str:
    return "🔴" if left < 0 else "🟡" if left < 7 else "🟢"


def renew_label(item) -> str:
    n, u = item["repeat_n"], item["repeat_unit"]
    return f"Продлено на {UNIT_NAME[u]}" if n == 1 else f"Продлено на {n} {UNIT_SHORT[u]}"


# ---------- пользователи и привязка ----------
def get_or_create_user(db, tg_id: int, name: str = ""):
    u = db.one("SELECT * FROM users WHERE telegram_id=?", (tg_id,))
    if not u:
        db.run("INSERT INTO users(telegram_id, name) VALUES(?,?)", (tg_id, name))
        u = db.one("SELECT * FROM users WHERE telegram_id=?", (tg_id,))
    return u


def create_link_token(db, user_id: int, ttl_min: int = 15, now: datetime | None = None) -> str:
    """Вызывается сайтом: вернуть токен для ссылки t.me/<бот>?start=<токен>."""
    now = now or datetime.now(timezone.utc)
    token = secrets.token_urlsafe(16)
    db.run("INSERT INTO link_tokens(token_hash, user_id, expires_at) VALUES(?,?,?)",
           (hashlib.sha256(token.encode()).hexdigest(), user_id,
            (now + timedelta(minutes=ttl_min)).isoformat()))
    return token


def link_account(db, tg_id: int, token: str, now: datetime | None = None):
    now = now or datetime.now(timezone.utc)
    th = hashlib.sha256(token.encode()).hexdigest()
    row = db.one("SELECT * FROM link_tokens WHERE token_hash=?", (th,))
    if not row or row["used_at"] or datetime.fromisoformat(row["expires_at"]) < now:
        return False, "Ссылка недействительна или устарела. Создайте новую в личном кабинете на сайте."
    site_id = row["user_id"]
    cur = db.one("SELECT * FROM users WHERE telegram_id=?", (tg_id,))
    if cur and cur["id"] != site_id:
        if db.one("SELECT 1 FROM items WHERE user_id=?", (cur["id"],)):
            return False, ("Этот Telegram уже используется с другими данными, поэтому "
                           "автоматически объединить аккаунты нельзя.")
        db.run("DELETE FROM users WHERE id=?", (cur["id"],))
    db.run("UPDATE users SET telegram_id=? WHERE id=?", (tg_id, site_id))
    db.run("UPDATE link_tokens SET used_at=? WHERE token_hash=?", (now.isoformat(), th))
    return True, "✅ Telegram привязан к вашему аккаунту. Теперь напоминания будут приходить сюда."


# ---------- карточки ----------
def add_item(db, user_id, title, due: date, cost, currency, mode: str) -> int:
    unit = {"once": None, "month": "month", "year": "year"}[mode]
    cur = db.run(
        "INSERT INTO items(user_id,title,category,next_date,repeat_n,repeat_unit,cost,currency,is_paid)"
        " VALUES(?,?,?,?,?,?,?,?,?)",
        (user_id, title, "Подписка" if unit else "Разовое", due.isoformat(), 1, unit,
         cost, currency, 1 if (cost and unit) else 0))
    return cur.lastrowid


def active_items(db, user_id):
    return db.q("SELECT * FROM items WHERE user_id=? AND status='active' ORDER BY next_date", (user_id,))


def monthly_totals(items) -> dict:
    k = {"day": 30.44, "week": 4.345, "month": 1, "year": 1 / 12}
    out = {}
    for it in items:
        if it["is_paid"] and it["cost"] and it["repeat_unit"]:
            m = it["cost"] * k[it["repeat_unit"]] / (it["repeat_n"] or 1)
            out[it["currency"]] = out.get(it["currency"], 0) + m
    return out


def apply_action(db, u, action: str, item_id: int, due: str, now: datetime | None = None):
    """r=продлено, c=отменено, s=напомнить позже, d=выброшено. Возвращает (код, карточка)."""
    it = db.one("SELECT * FROM items WHERE id=? AND user_id=?", (item_id, u["id"]))
    if not it:
        return "notfound", None
    if it["status"] != "active" or it["next_date"] != due:
        return "stale", it           # защита от повторного нажатия
    today = local_today(u, now)
    if action == "r":
        if not it["repeat_unit"]:
            return "once", it
        d = add_interval(date.fromisoformat(due), it["repeat_n"], it["repeat_unit"])
        while d < today:
            d = add_interval(d, it["repeat_n"], it["repeat_unit"])
        db.run("UPDATE items SET next_date=?, snoozed_until=NULL WHERE id=?", (d.isoformat(), item_id))
    elif action == "c":
        db.run("UPDATE items SET status='cancelled' WHERE id=?", (item_id,))
    elif action == "d":
        db.run("UPDATE items SET status='archived' WHERE id=?", (item_id,))
    elif action == "s":
        db.run("UPDATE items SET snoozed_until=? WHERE id=?",
               ((today + timedelta(days=1)).isoformat(), item_id))
    return "ok", db.one("SELECT * FROM items WHERE id=?", (item_id,))


# ---------- напоминания ----------
def collect_reminders(db, now: datetime):
    """Что нужно отправить прямо сейчас: [(user, item, kind, days_left)]."""
    out = []
    for u in db.q("SELECT * FROM users WHERE notify_tg=1 AND telegram_id IS NOT NULL"):
        local = now.astimezone(tz_of(u))
        if local.strftime("%H:%M") < u["notify_time"]:
            continue
        today = local.date()
        days = {int(x) for x in u["remind_days"].split(",") if x.strip().isdigit()}
        for it in active_items(db, u["id"]):
            left = (date.fromisoformat(it["next_date"]) - today).days
            sn = it["snoozed_until"]
            if sn:
                if today < date.fromisoformat(sn):
                    continue
                kind = f"snooze:{sn}"
            elif left in days:
                kind = f"d{left}"
            elif left < 0:
                kind = "overdue"
            else:
                continue
            out.append((u, it, kind, left))
    return out


def claim(db, item_id, user_id, due, kind) -> bool:
    """Занять отправку: второй процесс/перезапуск не пришлёт дубль."""
    cur = db.run("INSERT OR IGNORE INTO notifications_log(item_id,user_id,due_date,kind) VALUES(?,?,?,?)",
                 (item_id, user_id, due, kind))
    return cur.rowcount == 1


def unclaim(db, item_id, user_id, due, kind):
    db.run("DELETE FROM notifications_log WHERE item_id=? AND user_id=? AND due_date=? AND kind=?",
           (item_id, user_id, due, kind))


def after_sent(db, item, kind: str):
    if kind.startswith("snooze:"):
        db.run("UPDATE items SET snoozed_until=NULL WHERE id=?", (item["id"],))


def reminder_text(item, left: int) -> str:
    t = html.escape(item["title"])
    w = when(left)
    if item["repeat_unit"] is None:
        return f"⏳ Срок годности: <b>{t}</b> истекает {w}." if left >= 0 else f"⚠️ <b>{t}</b>: {w}."
    cost = f" ({money(item['cost'], item['currency'])})" if item["cost"] else ""
    if item["is_paid"]:
        if left >= 0:
            return f"💳 {w[0].upper() + w[1:]} спишется оплата за <b>{t}</b>{cost}."
        return f"⚠️ Оплата за <b>{t}</b>{cost}: {w}. Продлите или отмените."
    return f"🔔 <b>{t}</b>: срок наступает {w}." if left >= 0 else f"⚠️ <b>{t}</b>: {w}."


def keyboard_spec(item):
    i, due = item["id"], item["next_date"]
    later = ("⏰ Напомнить позже", f"s:{i}:{due}")
    if item["repeat_unit"] is None:
        return [("🗑 Выброшено", f"d:{i}:{due}"), later]
    return [(f"✅ {renew_label(item)}", f"r:{i}:{due}"), ("❌ Отменено", f"c:{i}:{due}"), later]
