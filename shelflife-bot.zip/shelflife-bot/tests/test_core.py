import unittest
from datetime import date, datetime, timedelta, timezone

from bot import services
from bot.db import DB
from bot.parser import parse_add

TODAY = date(2026, 11, 10)


def utc(y, mo, d, h, mi=0):
    return datetime(y, mo, d, h, mi, tzinfo=timezone.utc)


class T(unittest.TestCase):
    def setUp(self):
        self.db = DB(":memory:")
        self.u = services.get_or_create_user(self.db, 111, "Анна")

    def item(self, days, mode="month", cost=500.0, cur="RUB", title="Spotify"):
        return services.add_item(self.db, self.u["id"], title, TODAY + timedelta(days=days), cost, cur, mode)

    def test_parser(self):
        p = parse_add("Spotify 15.11 500rub", TODAY)
        self.assertEqual((p["title"], p["due"], p["cost"], p["currency"]), ("Spotify", date(2026, 11, 15), 500.0, "RUB"))
        p = parse_add("Netflix Premium 05.11 $9.99", TODAY)
        self.assertEqual((p["due"], p["currency"], p["cost"]), (date(2027, 11, 5), "USD", 9.99))
        self.assertIsNone(parse_add("Витамины 20.11", TODAY)["cost"])
        self.assertIsNone(parse_add("abc", TODAY))
        self.assertIsNone(parse_add("X 31.02", TODAY))

    def test_intervals(self):
        self.assertEqual(services.add_interval(date(2026, 1, 31), 1, "month"), date(2026, 2, 28))
        self.assertEqual(services.add_interval(date(2028, 2, 29), 1, "year"), date(2029, 2, 28))
        self.assertEqual(services.add_interval(date(2026, 12, 15), 1, "month"), date(2027, 1, 15))

    def test_renew_is_idempotent(self):
        i = self.item(3)
        due = (TODAY + timedelta(days=3)).isoformat()
        now = utc(2026, 11, 10, 7)
        self.assertEqual(services.apply_action(self.db, self.u, "r", i, due, now)[0], "ok")
        self.assertEqual(services.apply_action(self.db, self.u, "r", i, due, now)[0], "stale")
        self.assertEqual(self.db.one("SELECT next_date FROM items WHERE id=?", (i,))["next_date"], "2026-12-13")

    def test_other_user_cannot_touch_item(self):
        i = self.item(3)
        other = services.get_or_create_user(self.db, 222, "Борис")
        due = (TODAY + timedelta(days=3)).isoformat()
        self.assertEqual(services.apply_action(self.db, other, "c", i, due)[0], "notfound")

    def test_reminders_time_and_dedup(self):
        i = self.item(3)
        self.assertEqual(services.collect_reminders(self.db, utc(2026, 11, 10, 5)), [])   # 08:00 МСК
        got = services.collect_reminders(self.db, utc(2026, 11, 10, 7))                   # 10:00 МСК
        self.assertEqual([(g[2], g[3]) for g in got], [("d3", 3)])
        due = got[0][1]["next_date"]
        self.assertTrue(services.claim(self.db, i, self.u["id"], due, "d3"))
        self.assertFalse(services.claim(self.db, i, self.u["id"], due, "d3"))

    def test_snooze(self):
        i = self.item(3)
        due = (TODAY + timedelta(days=3)).isoformat()
        services.apply_action(self.db, self.u, "s", i, due, utc(2026, 11, 10, 7))
        self.assertEqual(services.collect_reminders(self.db, utc(2026, 11, 10, 8)), [])
        got = services.collect_reminders(self.db, utc(2026, 11, 11, 7))
        self.assertTrue(got and got[0][2].startswith("snooze:"))
        services.after_sent(self.db, got[0][1], got[0][2])
        self.assertIsNone(self.db.one("SELECT snoozed_until FROM items WHERE id=?", (i,))["snoozed_until"])

    def test_texts_and_buttons(self):
        i = self.item(1, cost=9.99, cur="USD")
        it = self.db.one("SELECT * FROM items WHERE id=?", (i,))
        self.assertEqual(services.reminder_text(it, 1), "💳 Завтра спишется оплата за <b>Spotify</b> ($9.99).")
        self.assertEqual(services.keyboard_spec(it)[0][0], "✅ Продлено на месяц")
        j = self.item(3, mode="once", cost=None, title="Витамины")
        it2 = self.db.one("SELECT * FROM items WHERE id=?", (j,))
        self.assertIn("истекает через 3 дня", services.reminder_text(it2, 3))
        self.assertEqual(len(services.keyboard_spec(it2)), 2)
        for _, data in services.keyboard_spec(it):
            self.assertLessEqual(len(data.encode()), 64)

    def test_spend(self):
        self.item(5, cost=300.0)
        self.item(5, mode="year", cost=1200.0, title="Домен")
        self.item(5, cost=10.0, cur="USD", title="Netflix")
        t = services.monthly_totals(services.active_items(self.db, self.u["id"]))
        self.assertAlmostEqual(t["RUB"], 400.0)
        self.assertAlmostEqual(t["USD"], 10.0)

    def test_link_token(self):
        self.db.run("INSERT INTO users(name) VALUES('site')")
        site = self.db.one("SELECT id FROM users WHERE name='site'")["id"]
        now = utc(2026, 11, 10, 7)
        tok = services.create_link_token(self.db, site, now=now)
        ok, _ = services.link_account(self.db, 111, tok, now=now)
        self.assertTrue(ok)
        self.assertEqual(self.db.one("SELECT telegram_id FROM users WHERE id=?", (site,))["telegram_id"], 111)
        self.assertFalse(services.link_account(self.db, 111, tok, now=now)[0])     # одноразовый
        old = services.create_link_token(self.db, site, now=now)
        self.assertFalse(services.link_account(self.db, 111, old, now=now + timedelta(minutes=16))[0])


if __name__ == "__main__":
    unittest.main()
